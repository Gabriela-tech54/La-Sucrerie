const products = [
  { id: 1, name: 'Macarons Clássicos', category: 'macarons', tag: 'favorito', description: 'Casquinha delicada e recheio cremoso em sabores selecionados.', price: 36, unit: 'caixa com 6', color: '#e8a391' },
  { id: 2, name: 'Macarons Especiais', category: 'macarons', tag: 'edição especial', description: 'Combinações especiais para presentear ou guardar o momento.', price: 42, unit: 'caixa com 6', color: '#b8614b' },
  { id: 3, name: 'Geladinho Gourmet', category: 'geladinhos', tag: 'refrescante', description: 'Cremoso, geladinho e perfeito para os dias quentes.', price: 4, unit: 'unidade', color: '#efd0b5' },
  { id: 4, name: 'Uva Delicada', category: 'especiais', tag: 'especial', description: 'Uma sobremesa delicada com toque frutado e acabamento artesanal.', price: 12, unit: 'unidade', color: '#b99cc7' },
  { id: 5, name: 'Ninho com Chocolate', category: 'geladinhos', tag: 'queridinho', description: 'Cremoso, chocolatudo e feito para matar a vontade de doce.', price: 5, unit: 'unidade', color: '#d5b38f' },
  { id: 6, name: 'Caixa Presente', category: 'especiais', tag: 'presenteável', description: 'Uma composição especial para transformar o doce em presente.', price: 68, unit: 'caixa', color: '#c57960' }
];

const brl = value => value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const state = { cart: [] };

function visualClass(category) {
  if (category === 'geladinhos') return 'ice';
  if (category === 'especiais') return 'special';
  return '';
}

function productCard(product) {
  return `
    <article class="product-card">
      <div class="product-visual ${visualClass(product.category)}" style="--product-color:${product.color}">
        <span class="eyebrow" style="position:absolute;top:16px;left:16px;background:rgba(255,253,248,.75);padding:7px 9px;margin:0;z-index:4;">${product.tag}</span>
      </div>
      <div class="product-meta">
        <h3>${product.name}</h3>
        <p>${product.description}</p>
        <div class="product-bottom">
          <span class="price">${brl(product.price)} <small>• ${product.unit}</small></span>
          <button class="add-btn" aria-label="Adicionar ${product.name}" data-add="${product.id}">+</button>
        </div>
      </div>
    </article>`;
}

function renderProducts(category = 'todos') {
  const filtered = category === 'todos' ? products : products.filter(p => p.category === category);
  document.getElementById('productGrid').innerHTML = filtered.map(productCard).join('');
}

document.getElementById('featuredProducts').innerHTML = products.slice(0, 3).map(productCard).join('');
renderProducts();

document.addEventListener('click', (event) => {
  const add = event.target.closest('[data-add]');
  if (add) addToCart(Number(add.dataset.add));
});

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    renderProducts(tab.dataset.category);
  });
});

function addToCart(id) {
  const product = products.find(p => p.id === id);
  const existing = state.cart.find(item => item.id === id);
  if (existing) existing.qty += 1;
  else state.cart.push({ ...product, qty: 1 });
  renderCart();
  openCart();
  toast(`${product.name} foi adicionado ao carrinho.`);
}

function changeQty(id, delta) {
  const item = state.cart.find(p => p.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) state.cart = state.cart.filter(p => p.id !== id);
  renderCart();
}

function renderCart() {
  const items = document.getElementById('cartItems');
  const count = state.cart.reduce((sum, item) => sum + item.qty, 0);
  const total = state.cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  document.getElementById('cartCount').textContent = count;
  document.getElementById('cartTotal').textContent = brl(total);
  if (!state.cart.length) {
    items.innerHTML = '<div class="empty">Seu carrinho ainda está vazio.<br>Escolha um docinho para começar. ♡</div>';
    return;
  }
  items.innerHTML = state.cart.map(item => `
    <div class="cart-item">
      <div class="cart-thumb" style="background:linear-gradient(145deg,${item.color},#f8e7dc)"></div>
      <div>
        <strong>${item.name}</strong>
        <small>${brl(item.price)} • ${item.unit}</small>
        <div class="qty">
          <button data-qty="${item.id}" data-delta="-1">−</button>
          <span>${item.qty}</span>
          <button data-qty="${item.id}" data-delta="1">+</button>
        </div>
      </div>
      <strong>${brl(item.price * item.qty)}</strong>
    </div>`).join('');
}

document.addEventListener('click', event => {
  const btn = event.target.closest('[data-qty]');
  if (btn) changeQty(Number(btn.dataset.qty), Number(btn.dataset.delta));
});

function openCart() {
  document.getElementById('cartDrawer').classList.add('open');
  document.getElementById('overlay').classList.add('open');
}
function closeCart() {
  document.getElementById('cartDrawer').classList.remove('open');
  document.getElementById('overlay').classList.remove('open');
}

document.getElementById('cartBtn').addEventListener('click', openCart);
document.getElementById('closeCart').addEventListener('click', closeCart);
document.getElementById('overlay').addEventListener('click', closeCart);

document.getElementById('checkoutBtn').addEventListener('click', () => {
  if (!state.cart.length) {
    toast('Seu carrinho está vazio.');
    return;
  }
  toast('Checkout entra na próxima etapa. O carrinho já está funcionando!');
});

document.getElementById('newsletterForm').addEventListener('submit', event => {
  event.preventDefault();
  const input = document.getElementById('emailInput');
  document.getElementById('newsletterMessage').textContent = `Prontinho! ${input.value} foi cadastrado.`;
  input.value = '';
});

document.getElementById('searchBtn').addEventListener('click', () => {
  document.getElementById('cardapio').scrollIntoView({ behavior: 'smooth' });
  toast('A busca será ligada ao cardápio na próxima etapa.');
});

function toast(message) {
  const element = document.getElementById('toast');
  element.textContent = message;
  element.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => element.classList.remove('show'), 2200);
}

renderCart();
