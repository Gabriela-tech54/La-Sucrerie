# La Sucrerie — site v1

Primeira versão visual da loja online.

## Estrutura
- `index.html` — estrutura da página
- `style.css` — identidade visual e responsividade
- `script.js` — catálogo, filtros e carrinho
- `assets/moodboard.png` — referência visual da identidade criada

## Como abrir
Abra `index.html` em um navegador.

## Próximas etapas
1. Trocar os produtos de demonstração pelos produtos reais e preços definidos.
2. Criar fotos reais/definitivas dos produtos.
3. Criar página individual de produto.
4. Integrar pedido por WhatsApp ou checkout.
5. Criar backend/banco para pedidos, estoque e clientes.
